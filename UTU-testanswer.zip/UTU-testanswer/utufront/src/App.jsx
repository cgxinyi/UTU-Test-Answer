import React, {Component} from 'react';
import "bootstrap/dist/css/bootstrap.min.css"
import axios from 'axios'
import { Row, Col, Alert, Container, Collapse} from "react-bootstrap";

class App extends Component {
    constructor(){
        super()
        this.state = {
        bitPrice:'',
        bitName: '',
        bitMktCap: '',
        tezosPrice: '',
        tezosName: '',
        tezosMktCap:'',
        bnbPrice: '',
        bnbName: '',
        bnbMktCap:'',
        bitcashPrice:'',
        bitcashName:'',
        bitcashMktCap:'',
        cardanoName: '',
        cardanoPrice: '',
        cardanoMktCap:'',
        tezosV:'',
        bnbV: '',
        bitcoinV: '',
        bitcashV: '',
        cardanoV: '',
        bitcoin24diff: '',
        bitcash24diff: '',
        tezos24diff: '',
        bnb24diff: '',
        cardano24diff:'',
        cardano7ddiff:'',
        bnb7ddiff:'',
        bitcoin7ddiff:'',
        tezos7ddiff:'',
        bitcash7ddiff:'',
        tezos30ddiff:'',
        bnb30ddiff:'',
        bitcoin30ddiff:'',
        bitcash30ddiff:'',
        bnb30ddiff:'',
        cardano30ddiff:''
    }
    
}



componentDidMount = () => {
    fetch('http://localhost:4000/app/findbitcoinPrice')
      .then((response) => response.json())
      .then((response) => this.setState({ bitPrice : response} ));

      fetch('http://localhost:4000/app/findbitcoinName')
      .then((response) => response.json())
      .then((response) => this.setState({ bitName : response} ));

      fetch('http://localhost:4000/app/findbitcoinMktCap')
      .then((response) => response.json())
      .then((response) => this.setState({ bitMktCap : response} ));

      fetch('http://localhost:4000/app/findtezosPrice')
      .then((response) => response.json())
      .then((response) => this.setState({ tezosPrice : response} ));

      fetch('http://localhost:4000/app/findtezosName')
      .then((response) => response.json())
      .then((response) => this.setState({ tezosName : response} ));

      fetch('http://localhost:4000/app/findtezosMktCap')
      .then((response) => response.json())
      .then((response) => this.setState({ tezosMktCap : response} ));

      fetch('http://localhost:4000/app/findbnbPrice')
      .then((response) => response.json())
      .then((response) => this.setState({ bnbPrice : response} ));

      fetch('http://localhost:4000/app/findbnbName')
      .then((response) => response.json())
      .then((response) => this.setState({ bnbName : response} ));

      fetch('http://localhost:4000/app/findbnbMktCap')
      .then((response) => response.json())
      .then((response) => this.setState({ bnbMktCap : response} ));

      
      fetch('http://localhost:4000/app/findbitcashPrice')
      .then((response) => response.json())
      .then((response) => this.setState({ bitcashPrice : response} ));

      fetch('http://localhost:4000/app/findbitcashName')
      .then((response) => response.json())
      .then((response) => this.setState({ bitcashName : response} ));

      fetch('http://localhost:4000/app/findbitcashMktCap')
      .then((response) => response.json())
      .then((response) => this.setState({ bitcashMktCap : response} ));

      fetch('http://localhost:4000/app/findcardanoPrice')
      .then((response) => response.json())
      .then((response) => this.setState({ cardanoPrice : response} ));

      fetch('http://localhost:4000/app/findcardanoName')
      .then((response) => response.json())
      .then((response) => this.setState({ cardanoName : response} ));

      fetch('http://localhost:4000/app/findcardanoMktCap')
      .then((response) => response.json())
      .then((response) => this.setState({ cardanoMktCap : response} ));

      fetch('http://localhost:4000/app/findbnb24hV')
      .then((response) => response.json())
      .then((response) => this.setState({ bnbV : response} ));

      fetch('http://localhost:4000/app/findbitcash24hV')
      .then((response) => response.json())
      .then((response) => this.setState({ bitcashV : response} ));

      fetch('http://localhost:4000/app/findbitcoin24hV')
      .then((response) => response.json())
      .then((response) => this.setState({ bitcoinV : response} ));

      fetch('http://localhost:4000/app/findcardano24hV')
      .then((response) => response.json())
      .then((response) => this.setState({ cardanoV : response} ));

      fetch('http://localhost:4000/app/findtezos24hV')
      .then((response) => response.json())
      .then((response) => this.setState({ tezosV : response} ));

      fetch('http://localhost:4000/app/findbitcoin24hVdiff')
      .then((response) => response.json())
      .then((response) => this.setState({ bitcoin24diff: response} ));

      fetch('http://localhost:4000/app/findbitcash24hVdiff')
      .then((response) => response.json())
      .then((response) => this.setState({ bitcash24diff: response} ));

      fetch('http://localhost:4000/app/findtezos24hVdiff')
      .then((response) => response.json())
      .then((response) => this.setState({ tezos24diff: response} ));

      fetch('http://localhost:4000/app/findbnb24hVdiff')
      .then((response) => response.json())
      .then((response) => this.setState({ bnb24diff: response} ));

      fetch('http://localhost:4000/app/findcardano24hVdiff')
      .then((response) => response.json())
      .then((response) => this.setState({ cardano24diff: response} ));

      fetch('http://localhost:4000/app/findcardano7dVdiff')
      .then((response) => response.json())
      .then((response) => this.setState({ cardano7ddiff: response} ));

      fetch('http://localhost:4000/app/findbnb7dVdiff')
      .then((response) => response.json())
      .then((response) => this.setState({ bnb7ddiff: response} ));

      fetch('http://localhost:4000/app/findbitcoin7dVdiff')
      .then((response) => response.json())
      .then((response) => this.setState({ bitcoin7ddiff: response} ));

      fetch('http://localhost:4000/app/findtezos7dVdiff')
      .then((response) => response.json())
      .then((response) => this.setState({ tezos7ddiff: response} ));

      fetch('http://localhost:4000/app/findbitcash7dVdiff')
      .then((response) => response.json())
      .then((response) => this.setState({ bitcash7ddiff: response} ));

      fetch('http://localhost:4000/app/findtezos30dVdiff')
      .then((response) => response.json())
      .then((response) => this.setState({ tezos30ddiff: response} ));

      fetch('http://localhost:4000/app/findbnb30dVdiff')
      .then((response) => response.json())
      .then((response) => this.setState({ bnb30ddiff: response} ));

      fetch('http://localhost:4000/app/findbitcoin30dVdiff')
      .then((response) => response.json())
      .then((response) => this.setState({ bitcoin30ddiff: response} ));

      fetch('http://localhost:4000/app/findbitcash30dVdiff')
      .then((response) => response.json())
      .then((response) => this.setState({ bitcash30ddiff: response} ));

      fetch('http://localhost:4000/app/findbnb30dVdiff')
      .then((response) => response.json())
      .then((response) => this.setState({ bitcash30ddiff: response} ));

      fetch('http://localhost:4000/app/findcardano30dVdiff')
      .then((response) => response.json())
      .then((response) => this.setState({ cardano30ddiff: response} ));
}
  

    
    render(){
        return (
            
        <div>
             <ul>
          
        </ul>
            <div className='container' >
                <h1 style={{display: 'flex',  justifyContent:'center', alignItems:'center',marginTop:'2%'}}>Crypto Historical Data</h1>
                
                    <Row className="title" style={{marginTop:'2%'}}>
                        <Col md={1}>
                            <h2>#</h2>
                        </Col>

                        <Col md={1}>
                            <h2>Coin</h2>
                        </Col>

                        <Col md={2}>
                            <h2>Price</h2>
                        </Col>

                        <Col md={2}>
                            <h2>24h Volume</h2>
                        </Col>
                        <Col md={1}>
                            <h2>24h</h2>
                        </Col>
                        <Col md={1}>
                            <h2>7d</h2>
                        </Col>
                        <Col md={1}>
                            <h2>30d</h2>
                        </Col>

                        <Col md={2}>
                            <h2>Mkt Cap</h2>
                        </Col>
                    </Row>

                    <Row className="history1" style={{marginTop:'2%'}}>
                        <Col md={1}>
                            <h3>1</h3>
                        </Col>
                        <Col md={1}>
                            <h3>{this.state.bitName}</h3>
                        </Col>

                        <Col md={2}>
                           <h3> {this.state.bitPrice}</h3>
                        </Col>

                        <Col md={2}>
                            <h3>{this.state.bitcoinV}</h3>
                        </Col>

                        <Col md={1}>
                            <h3>{this.state.bitcoin24diff}</h3>
                        </Col>

                        <Col md={1}>
                            <h3>{this.state.bitcoin7ddiff}</h3>
                        </Col>

                        <Col md={1}>
                            <h3>{this.state.bitcoin30ddiff}</h3>
                        </Col>

                        <Col md={2}>
                            <h3>{this.state.bitMktCap}</h3>
                        </Col>
                       
                    </Row>

                    <Row className="history2" style={{marginTop:'2%'}}>
                        <Col md={1}>
                            <h3>2</h3>
                        </Col>
                        <Col md={1}>
                            <h3>{this.state.tezosName}</h3>
                        </Col>

                        <Col md={2}>
                           <h3> {this.state.tezosPrice}</h3>
                        </Col>

                        <Col md={2}>
                            <h3>{this.state.tezosV}</h3>
                        </Col>
                        <Col md={1}>
                            <h3>{this.state.tezos24diff}</h3>
                        </Col>
                        <Col md={1}>
                            <h3>{this.state.tezos7ddiff}</h3>
                        </Col>

                        <Col md={1}>
                            <h3>{this.state.tezos30ddiff}</h3>
                        </Col>

                        <Col md={2}>
                            <h3>{this.state.tezosMktCap}</h3>
                        </Col>
                       
                    </Row>
                    <Row className="history3" style={{marginTop:'2%'}}>
                        <Col md={1}>
                            <h3>3</h3>
                        </Col>
                        <Col md={1}>
                            <h3>{this.state.bnbName}</h3>
                        </Col>

                        <Col md={2}>
                           <h3> {this.state.bnbPrice}</h3>
                        </Col>

                        <Col md={2}>
                            <h3>{this.state.bnbV}</h3>
                        </Col>

                        <Col md={1}>
                            <h3>{this.state.bnb24diff}</h3>
                        </Col>
                        <Col md={1}>
                            <h3>{this.state.bnb7ddiff}</h3>
                        </Col>
                        <Col md={1}>
                            <h3>{this.state.bnb30ddiff}</h3>
                        </Col>

                        <Col md={2}>
                            <h3>{this.state.bnbMktCap}</h3>
                        </Col>
                       
                    </Row>
                    

                    <Row className="history4" style={{marginTop:'2%'}}>
                        <Col md={1}>
                            <h3>4</h3>
                        </Col>
                        <Col md={1}>
                            <h3>{this.state.bitcashName}</h3>
                        </Col>

                        <Col md={2}>
                           <h3> {this.state.bitcashPrice}</h3>
                        </Col>

                        <Col md={2}>
                            <h3>{this.state.bitcashV}</h3>
                        </Col>
                        <Col md={1}>
                            <h3>{this.state.bitcash24diff}</h3>
                        </Col>

                        <Col md={1}>
                            <h3>{this.state.bitcash7ddiff}</h3>
                        </Col>

                        <Col md={1}>
                            <h3>{this.state.bitcash30ddiff}</h3>
                        </Col>

                        <Col md={2}>
                            <h3>{this.state.bitcashMktCap}</h3>
                        </Col>
                       
                    </Row>

                    <Row className="history5" style={{marginTop:'2%'}}>
                        <Col md={1}>
                            <h3>5</h3>
                        </Col>
                        <Col md={1}>
                            <h3>{this.state.cardanoName}</h3>
                        </Col>

                        <Col md={2}>
                           <h3> {this.state.cardanoPrice}</h3>
                        </Col>

                        <Col md={2}>
                            <h3>{this.state.cardanoV}</h3>
                        </Col>
                        <Col md={1}>
                            <h3>{this.state.cardano24diff}</h3>
                        </Col>

                        <Col md={1}>
                            <h3>{this.state.cardano7ddiff}</h3>
                        </Col>

                        <Col md={1}>
                            <h3>{this.state.cardano30ddiff}</h3>
                        </Col>

                        <Col md={2}>
                            <h3>{this.state.cardanoMktCap}</h3>
                        </Col>
                       
                    </Row>
                
            </div>
        </div> 
        );
    }
        
    
}

export default App;