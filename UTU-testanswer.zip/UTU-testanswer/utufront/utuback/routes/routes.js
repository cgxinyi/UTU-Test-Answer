const express = require('express')
const router = express.Router()
const utuTemplateC = require('../models/utuModels')


router.post('/request',(request, response)=>{
    const input = new utuTemplateC({
        number:request.body.number
    })
    input.save()
    .then(data =>{
        response.json(data)
    })
    .catch(error =>{
        response.json(error)
    })

})

router.get('/find', async (req, res) => {
    try
    {
        const allcurrencies = await utuTemplateC.find();
         console.log(allcurrencies);
        res.json(allcurrencies);
    }catch(err)
    {
        res.status(500).json({"cannot find data":err})
    }
});

router.get('/findbitcoinPrice', async (req, res) => {
    try
    {
        const bitcoin = await utuTemplateC.find({Currency:"bitcoin"}).select("Open -_id").sort({date: -1}).limit(1)
        console.log(bitcoin)
        var pricestr = bitcoin.toString()
        console.log(pricestr)
        var pricetemp = pricestr.replace(",",'')
        var price = parseFloat(pricetemp.match(/[\d\.]+/))
        console.log(pricetemp, price)
        res.json(price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
    }catch(err)
    {
        res.status(500).json({"cannot find bitcoin":err})
    }
});
  
router.get('/findbitcoinName', async (req, res) => {
    try
    {
        const bitcoin = await utuTemplateC.find({Currency:"bitcoin"}).select("Currency -_id").sort({date: -1}).limit(1)
        console.log(bitcoin)
        var nameStr = bitcoin.toString().split("Currency: '")
        var trimName = nameStr[1].split("' }")
        var finalName = trimName[0]
        console.log(nameStr, trimName)
        
        
        res.json(finalName);
    }catch(err)
    {
        res.status(500).json({"cannot find bitcoin":err})
    }
}); 

router.get('/findbitcoinMktCap', async (req, res) => {
    try
    {
        const bitcoin = await utuTemplateC.find({Currency:"bitcoin"}).select("MarketCap -_id").sort({date: -1}).limit(1)
        console.log(bitcoin)
        var marketCapStr = bitcoin.toString()
        console.log(marketCapStr)
        var marketTemp = marketCapStr.split(',').join('');
        var finalMarket = parseFloat(marketTemp.match(/[\d\.]+/))

       
        console.log(marketTemp, finalMarket)
        res.json(finalMarket.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
    }catch(err)
    {
        res.status(500).json({"cannot find bitcoin":err})
    }
}); 

router.get('/findtezosPrice', async (req, res) => {
    try
    {
        const tezos = await utuTemplateC.find({Currency:"tezos"}).select("Open -_id").sort({date: -1}).limit(1)
        console.log(tezos)
        var pricestr = tezos.toString()
        console.log(pricestr)
        var pricetemp = pricestr.replace(",",'')
        var price = parseFloat(pricetemp.match(/[\d\.]+/))
        console.log(pricetemp, price)
        res.json(price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
    }catch(err)
    {
        res.status(500).json({"cannot find tezos":err})
    }
});

router.get('/findtezosName', async (req, res) => {
    try
    {
        const tezos = await utuTemplateC.find({Currency:"tezos"}).select("Currency -_id").sort({date: -1}).limit(1)
        console.log(tezos)
        var nameStr = tezos.toString().split("Currency: '")
        var trimName = nameStr[1].split("' }")
        var finalName = trimName[0]
        console.log(nameStr, trimName)
        
        
        res.json(finalName);
    }catch(err)
    {
        res.status(500).json({"cannot find tezos":err})
    }
}); 

router.get('/findtezosMktCap', async (req, res) => {
    try
    {
        const tezos = await utuTemplateC.find({Currency:"tezos"}).select("MarketCap -_id").sort({date: -1}).limit(1)
        console.log(tezos)
        var marketCapStr = tezos.toString()
        console.log(marketCapStr)
        var marketTemp = marketCapStr.split(',').join('');
        var finalMarket = parseFloat(marketTemp.match(/[\d\.]+/))

       
        console.log(marketTemp, finalMarket)
        res.json(finalMarket.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
    }catch(err)
    {
        res.status(500).json({"cannot find tezos":err})
    }
}); 

router.get('/findbnbPrice', async (req, res) => {
    try
    {
        const bnb = await utuTemplateC.find({Currency:"bnb"}).select("Open -_id").sort({date: -1}).limit(1)
        console.log(bnb)
        var pricestr = bnb.toString()
        console.log(pricestr)
        var pricetemp = pricestr.replace(",",'')
        var price = parseFloat(pricetemp.match(/[\d\.]+/))
        console.log(pricetemp, price)
        res.json(price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
    }catch(err)
    {
        res.status(500).json({"cannot find bnb":err})
    }
});

router.get('/findbnbName', async (req, res) => {
    try
    {
        const bnb = await utuTemplateC.find({Currency:"bnb"}).select("Currency -_id").sort({date: -1}).limit(1)
        console.log(bnb)
        var nameStr = bnb.toString().split("Currency: '")
        var trimName = nameStr[1].split("' }")
        var finalName = trimName[0]
        console.log(nameStr, trimName)
        
        
        res.json(finalName);
    }catch(err)
    {
        res.status(500).json({"cannot find bnb":err})
    }
}); 

router.get('/findbnbMktCap', async (req, res) => {
    try
    {
        const bnb = await utuTemplateC.find({Currency:"bnb"}).select("MarketCap -_id").sort({date: -1}).limit(1)
        console.log(bnb)
        var marketCapStr = bnb.toString()
        console.log(marketCapStr)
        var marketTemp = marketCapStr.split(',').join('');
        var finalMarket = parseFloat(marketTemp.match(/[\d\.]+/))

       
        console.log(marketTemp, finalMarket)
        res.json(finalMarket.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
    }catch(err)
    {
        res.status(500).json({"cannot find bnb":err})
    }
}); 


router.get('/findbitcashPrice', async (req, res) => {
    try
    {
        const bitcash = await utuTemplateC.find({Currency:"bitcoin-cash"}).select("Open -_id").sort({date: -1}).limit(1)
        console.log(bitcash)
        var pricestr = bitcash.toString()
        console.log(pricestr)
        var pricetemp = pricestr.replace(",",'')
        var price = parseFloat(pricetemp.match(/[\d\.]+/))
        console.log(pricetemp, price)
        res.json(price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
    }catch(err)
    {
        res.status(500).json({"cannot find bitcash":err})
    }
});

router.get('/findbitcashName', async (req, res) => {
    try
    {
        const bitcash = await utuTemplateC.find({Currency:"bitcoin-cash"}).select("Currency -_id").sort({date: -1}).limit(1)
        console.log(bitcash)
        var nameStr = bitcash.toString().split("Currency: '")
        var trimName = nameStr[1].split("' }")
        var finalName = trimName[0]
        console.log(nameStr, trimName)
        
        
        res.json(finalName);
    }catch(err)
    {
        res.status(500).json({"cannot find bitcash":err})
    }
}); 

router.get('/findbitcashMktCap', async (req, res) => {
    try
    {
        const bitcash = await utuTemplateC.find({Currency:"bitcoin-cash"}).select("MarketCap -_id").sort({date: -1}).limit(1)
        console.log(bitcash)
        var marketCapStr = bitcash.toString()
        console.log(marketCapStr)
        var marketTemp = marketCapStr.split(',').join('');
        var finalMarket = parseFloat(marketTemp.match(/[\d\.]+/))

       
        console.log(marketTemp, finalMarket)
        res.json(finalMarket.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
    }catch(err)
    {
        res.status(500).json({"cannot find bitcash":err})
    }
}); 

router.get('/findcardanoPrice', async (req, res) => {
    try
    {
        const cardano = await utuTemplateC.find({Currency:"cardano"}).select("Open -_id").sort({date: -1}).limit(1)
        console.log(cardano)
        var pricestr = cardano.toString()
        console.log(pricestr)
        var pricetemp = pricestr.replace(",",'')
        var price = parseFloat(pricetemp.match(/[\d\.]+/))
        console.log(pricetemp, price)
        res.json(price);
    }catch(err)
    {
        res.status(500).json({"cannot find cardano":err})
    }
});

router.get('/findcardanoName', async (req, res) => {
    try
    {
        const cardano = await utuTemplateC.find({Currency:"cardano"}).select("Currency -_id").sort({date: -1}).limit(1)
        console.log(cardano)
        var nameStr = cardano.toString().split("Currency: '")
        var trimName = nameStr[1].split("' }")
        var finalName = trimName[0]
        console.log(nameStr, trimName)
        
        
        res.json(finalName);
    }catch(err)
    {
        res.status(500).json({"cannot find cardano":err})
    }
}); 

router.get('/findcardanoMktCap', async (req, res) => {
    try
    {
        const cardano = await utuTemplateC.find({Currency:"cardano"}).select("MarketCap -_id").sort({date: -1}).limit(1)
        console.log(cardano)
        var marketCapStr = cardano.toString()
        console.log(marketCapStr)
        var marketTemp = marketCapStr.split(',').join('');
        var finalMarket = parseFloat(marketTemp.match(/[\d\.]+/))

       
        console.log(marketTemp, finalMarket)
        res.json(finalMarket.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
    }catch(err)
    {
        res.status(500).json({"cannot find cardano":err})
    }
}); 

router.get('/findbitcoin24hV', async (req, res) => {
    try
    {
        const bitcoin= await utuTemplateC.find({Currency:"bitcoin"}).select("Volume -_id").sort({date: -1}).limit(1)
        console.log(bitcoin)
        var volStr = bitcoin.toString()
        console.log(volStr)
        var volTemp = volStr.split(',').join('');
        var finalVol= parseFloat(volTemp.match(/[\d\.]+/))

       
        console.log(volTemp, finalVol)
        res.json(finalVol.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
    }catch(err)
    {
        res.status(500).json({"cannot find bitcoin":err})
    }
}); 


router.get('/findtezos24hV', async (req, res) => {
    try
    {
        const tezos= await utuTemplateC.find({Currency:"tezos"}).select("Volume -_id").sort({date: -1}).limit(1)
        console.log(tezos)
        var volStr = tezos.toString()
        console.log(volStr)
        var volTemp = volStr.split(',').join('');
        var finalVol= parseFloat(volTemp.match(/[\d\.]+/))

       
        console.log(volTemp, finalVol)
        res.json(finalVol.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
    }catch(err)
    {
        res.status(500).json({"cannot find tezos":err})
    }
}); 

router.get('/findbitcash24hV', async (req, res) => {
    try
    {
        const bitcash= await utuTemplateC.find({Currency:"bitcoin-cash"}).select("Volume -_id").sort({date: -1}).limit(1)
        console.log(bitcash)
        var volStr = bitcash.toString()
        console.log(volStr)
        var volTemp = volStr.split(',').join('');
        var finalVol= parseFloat(volTemp.match(/[\d\.]+/))

       
        console.log(volTemp, finalVol)
        res.json(finalVol.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
    }catch(err)
    {
        res.status(500).json({"cannot find bitcash":err})
    }
}); 

router.get('/findcardano24hV', async (req, res) => {
    try
    {
        const cardano= await utuTemplateC.find({Currency:"cardano"}).select("Volume -_id").sort({date: -1}).limit(1)
        console.log(cardano)
        var volStr = cardano.toString()
        console.log(volStr)
        var volTemp = volStr.split(',').join('');
        var finalVol= parseFloat(volTemp.match(/[\d\.]+/))

       
        console.log(volTemp, finalVol)
        res.json(finalVol.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
    }catch(err)
    {
        res.status(500).json({"cannot find cardano":err})
    }
}); 

router.get('/findbnb24hV', async (req, res) => {
    try
    {
        const bnb= await utuTemplateC.find({Currency:"bnb"}).select("Volume -_id").sort({date: -1}).limit(1)
        console.log(bnb)
        var volStr = bnb.toString()
        console.log(volStr)
        var volTemp = volStr.split(',').join('');
        var finalVol= parseFloat(volTemp.match(/[\d\.]+/))

       
        console.log(volTemp, finalVol)
        res.json(finalVol.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
    }catch(err)
    {
        res.status(500).json({"cannot find bnb":err})
    }
}); 

router.get('/findbitcoin24hVdiff', async (req, res) => {
    try
    {
        const bitcointoday= await utuTemplateC.find({Currency:"bitcoin"}).select("Volume -_id").sort({date: -1}).limit(1)
        const bitcoinytd= await utuTemplateC.find({Currency:"bitcoin"}).select("Volume -_id").sort({date: -1}).skip(1).limit(1)
        console.log(bitcointoday,bitcoinytd)
        var volStrToday = bitcointoday.toString()
        var volStrYtd = bitcoinytd.toString()
        console.log(volStrToday,volStrYtd)
        var volTempToday = volStrToday.split(',').join('');
        var volTempYtd = volStrYtd.split(',').join('');
        console.log(volTempToday, volTempYtd)
        var finalVolToday= parseFloat(volTempToday.match(/[\d\.]+/))
        var finalVolYtd= parseFloat(volTempYtd.match(/[\d\.]+/))
        console.log(finalVolToday,finalVolYtd)
        
        
        var finalDiff = finalVolToday - finalVolYtd
        var finalDiffinPar = finalDiff/finalVolYtd*100
        console.log(finalDiff, finalDiffinPar)
        var outputDiff = finalDiffinPar.toFixed(2).toString()
        res.json(outputDiff+"%");
    }catch(err)
    {
        res.status(500).json({"cannot find bitcoin":err})
    }
}); 

router.get('/findbitcash24hVdiff', async (req, res) => {
    try
    {
        const bitcointoday= await utuTemplateC.find({Currency:"bitcoin-cash"}).select("Volume -_id").sort({date: -1}).limit(1)
        const bitcoinytd= await utuTemplateC.find({Currency:"bitcoin-cash"}).select("Volume -_id").sort({date: -1}).skip(1).limit(1)
        console.log(bitcointoday,bitcoinytd)
        var volStrToday = bitcointoday.toString()
        var volStrYtd = bitcoinytd.toString()
        console.log(volStrToday,volStrYtd)
        var volTempToday = volStrToday.split(',').join('');
        var volTempYtd = volStrYtd.split(',').join('');
        console.log(volTempToday, volTempYtd)
        var finalVolToday= parseFloat(volTempToday.match(/[\d\.]+/))
        var finalVolYtd= parseFloat(volTempYtd.match(/[\d\.]+/))
        console.log(finalVolToday,finalVolYtd)
        
        
        var finalDiff = finalVolToday - finalVolYtd
        var finalDiffinPar = finalDiff/finalVolYtd*100
        console.log(finalDiff, finalDiffinPar)
        var outputDiff = finalDiffinPar.toFixed(2).toString()
        res.json(outputDiff+"%");
    }catch(err)
    {
        res.status(500).json({"cannot find bitcash":err})
    }
}); 

router.get('/findtezos24hVdiff', async (req, res) => {
    try
    {
        const tezostoday= await utuTemplateC.find({Currency:"tezos"}).select("Volume -_id").sort({date: -1}).limit(1)
        const tezosytd= await utuTemplateC.find({Currency:"tezos"}).select("Volume -_id").sort({date: -1}).skip(1).limit(1)
        console.log(tezostoday,tezosytd)
        var volStrToday = tezostoday.toString()
        var volStrYtd = tezosytd.toString()
        console.log(volStrToday,volStrYtd)
        var volTempToday = volStrToday.split(',').join('');
        var volTempYtd = volStrYtd.split(',').join('');
        console.log(volTempToday, volTempYtd)
        var finalVolToday= parseFloat(volTempToday.match(/[\d\.]+/))
        var finalVolYtd= parseFloat(volTempYtd.match(/[\d\.]+/))
        console.log(finalVolToday,finalVolYtd)
        
        
        var finalDiff = finalVolToday - finalVolYtd
        var finalDiffinPar = finalDiff/finalVolYtd*100
        console.log(finalDiff, finalDiffinPar)
        var outputDiff = finalDiffinPar.toFixed(2).toString()
        res.json(outputDiff+"%");
    }catch(err)
    {
        res.status(500).json({"cannot find tezos":err})
    }
}); 

router.get('/findbnb24hVdiff', async (req, res) => {
    try
    {
        const bnbtoday= await utuTemplateC.find({Currency:"bnb"}).select("Volume -_id").sort({date: -1}).limit(1)
        const bnbytd= await utuTemplateC.find({Currency:"bnb"}).select("Volume -_id").sort({date: -1}).skip(1).limit(1)
        console.log(bnbtoday,bnbytd)
        var volStrToday = bnbtoday.toString()
        var volStrYtd = bnbytd.toString()
        console.log(volStrToday,volStrYtd)
        var volTempToday = volStrToday.split(',').join('');
        var volTempYtd = volStrYtd.split(',').join('');
        console.log(volTempToday, volTempYtd)
        var finalVolToday= parseFloat(volTempToday.match(/[\d\.]+/))
        var finalVolYtd= parseFloat(volTempYtd.match(/[\d\.]+/))
        console.log(finalVolToday,finalVolYtd)
        
        
        var finalDiff = finalVolToday - finalVolYtd
        var finalDiffinPar = finalDiff/finalVolYtd*100
        console.log(finalDiff, finalDiffinPar)
        var outputDiff = finalDiffinPar.toFixed(2).toString()
        res.json(outputDiff+"%");
    }catch(err)
    {
        res.status(500).json({"cannot find bnb":err})
    }
}); 

router.get('/findcardano24hVdiff', async (req, res) => {
    try
    {
        const cardanotoday= await utuTemplateC.find({Currency:"cardano"}).select("Volume -_id").sort({date: -1}).limit(1)
        const cardanoytd= await utuTemplateC.find({Currency:"cardano"}).select("Volume -_id").sort({date: -1}).skip(1).limit(1)
        console.log(cardanotoday,cardanoytd)
        var volStrToday = cardanotoday.toString()
        var volStrYtd = cardanoytd.toString()
        console.log(volStrToday,volStrYtd)
        var volTempToday = volStrToday.split(',').join('');
        var volTempYtd = volStrYtd.split(',').join('');
        console.log(volTempToday, volTempYtd)
        var finalVolToday= parseFloat(volTempToday.match(/[\d\.]+/))
        var finalVolYtd= parseFloat(volTempYtd.match(/[\d\.]+/))
        console.log(finalVolToday,finalVolYtd)
        
        
        var finalDiff = finalVolToday - finalVolYtd
        var finalDiffinPar = finalDiff/finalVolYtd*100
        console.log(finalDiff, finalDiffinPar)
        var outputDiff = finalDiffinPar.toFixed(2).toString()
        res.json(outputDiff+"%");
    }catch(err)
    {
        res.status(500).json({"cannot find bnb":err})
    }
});

router.get('/findcardano7dVdiff', async (req, res) => {
    try
    {
        const cardanotoday= await utuTemplateC.find({Currency:"cardano"}).select("Volume -_id").sort({date: -1}).limit(1)
        const cardano7d= await utuTemplateC.find({Currency:"cardano"}).select("Volume -_id").sort({date: -1}).skip(7).limit(1)
        console.log(cardanotoday,cardano7d)
        var volStrToday = cardanotoday.toString()
        var volStrYtd = cardano7d.toString()
        console.log(volStrToday,volStrYtd)
        var volTempToday = volStrToday.split(',').join('');
        var volTempYtd = volStrYtd.split(',').join('');
        console.log(volTempToday, volTempYtd)
        var finalVolToday= parseFloat(volTempToday.match(/[\d\.]+/))
        var finalVolYtd= parseFloat(volTempYtd.match(/[\d\.]+/))
        console.log(finalVolToday,finalVolYtd)
        
        
        var finalDiff = finalVolToday - finalVolYtd
        var finalDiffinPar = finalDiff/finalVolYtd*100
        console.log(finalDiff, finalDiffinPar)
        var outputDiff = finalDiffinPar.toFixed(2).toString()
        res.json(outputDiff+"%");
    }catch(err)
    {
        res.status(500).json({"cannot find cardano":err})
    }
});

router.get('/findbnb7dVdiff', async (req, res) => {
    try
    {
        const bnbtoday= await utuTemplateC.find({Currency:"bnb"}).select("Volume -_id").sort({date: -1}).limit(1)
        const bnb7d= await utuTemplateC.find({Currency:"bnb"}).select("Volume -_id").sort({date: -1}).skip(7).limit(1)
        console.log(bnbtoday,bnb7d)
        var volStrToday = bnbtoday.toString()
        var volStrYtd = bnb7d.toString()
        console.log(volStrToday,volStrYtd)
        var volTempToday = volStrToday.split(',').join('');
        var volTempYtd = volStrYtd.split(',').join('');
        console.log(volTempToday, volTempYtd)
        var finalVolToday= parseFloat(volTempToday.match(/[\d\.]+/))
        var finalVolYtd= parseFloat(volTempYtd.match(/[\d\.]+/))
        console.log(finalVolToday,finalVolYtd)
        
        
        var finalDiff = finalVolToday - finalVolYtd
        var finalDiffinPar = finalDiff/finalVolYtd*100
        console.log(finalDiff, finalDiffinPar)
        var outputDiff = finalDiffinPar.toFixed(2).toString()
        res.json(outputDiff+"%");
    }catch(err)
    {
        res.status(500).json({"cannot find bnb":err})
    }
});

router.get('/findbitcoin7dVdiff', async (req, res) => {
    try
    {
        const bitcointoday= await utuTemplateC.find({Currency:"bitcoin"}).select("Volume -_id").sort({date: -1}).limit(1)
        const bitcoin7d= await utuTemplateC.find({Currency:"bitcoin"}).select("Volume -_id").sort({date: -1}).skip(7).limit(1)
        console.log(bitcointoday,bitcoin7d)
        var volStrToday = bitcointoday.toString()
        var volStrYtd = bitcoin7d.toString()
        console.log(volStrToday,volStrYtd)
        var volTempToday = volStrToday.split(',').join('');
        var volTempYtd = volStrYtd.split(',').join('');
        console.log(volTempToday, volTempYtd)
        var finalVolToday= parseFloat(volTempToday.match(/[\d\.]+/))
        var finalVolYtd= parseFloat(volTempYtd.match(/[\d\.]+/))
        console.log(finalVolToday,finalVolYtd)
        
        
        var finalDiff = finalVolToday - finalVolYtd
        var finalDiffinPar = finalDiff/finalVolYtd*100
        console.log(finalDiff, finalDiffinPar)
        var outputDiff = finalDiffinPar.toFixed(2).toString()
        res.json(outputDiff+"%");
    }catch(err)
    {
        res.status(500).json({"cannot find bitcoin":err})
    }
});

router.get('/findbitcash7dVdiff', async (req, res) => {
    try
    {
        const bitcashtoday= await utuTemplateC.find({Currency:"bitcoin-cash"}).select("Volume -_id").sort({date: -1}).limit(1)
        const bitcash7d= await utuTemplateC.find({Currency:"bitcoin-cash"}).select("Volume -_id").sort({date: -1}).skip(7).limit(1)
        console.log(bitcashtoday,bitcash7d)
        var volStrToday = bitcashtoday.toString()
        var volStrYtd = bitcash7d.toString()
        console.log(volStrToday,volStrYtd)
        var volTempToday = volStrToday.split(',').join('');
        var volTempYtd = volStrYtd.split(',').join('');
        console.log(volTempToday, volTempYtd)
        var finalVolToday= parseFloat(volTempToday.match(/[\d\.]+/))
        var finalVolYtd= parseFloat(volTempYtd.match(/[\d\.]+/))
        console.log(finalVolToday,finalVolYtd)
        
        
        var finalDiff = finalVolToday - finalVolYtd
        var finalDiffinPar = finalDiff/finalVolYtd*100
        console.log(finalDiff, finalDiffinPar)
        var outputDiff = finalDiffinPar.toFixed(2).toString()
        res.json(outputDiff+"%");
    }catch(err)
    {
        res.status(500).json({"cannot find bitcash":err})
    }
});


router.get('/findtezos7dVdiff', async (req, res) => {
    try
    {
        const tezostoday= await utuTemplateC.find({Currency:"tezos"}).select("Volume -_id").sort({date: -1}).limit(1)
        const tezos7d= await utuTemplateC.find({Currency:"tezos"}).select("Volume -_id").sort({date: -1}).skip(7).limit(1)
        console.log(tezostoday,tezos7d)
        var volStrToday = tezostoday.toString()
        var volStrYtd = tezos7d.toString()
        console.log(volStrToday,volStrYtd)
        var volTempToday = volStrToday.split(',').join('');
        var volTempYtd = volStrYtd.split(',').join('');
        console.log(volTempToday, volTempYtd)
        var finalVolToday= parseFloat(volTempToday.match(/[\d\.]+/))
        var finalVolYtd= parseFloat(volTempYtd.match(/[\d\.]+/))
        console.log(finalVolToday,finalVolYtd)
        
        
        var finalDiff = finalVolToday - finalVolYtd
        var finalDiffinPar = finalDiff/finalVolYtd*100
        console.log(finalDiff, finalDiffinPar)
        var outputDiff = finalDiffinPar.toFixed(2).toString()
        res.json(outputDiff+"%");
    }catch(err)
    {
        res.status(500).json({"cannot find tezos":err})
    }
});

router.get('/findtezos30dVdiff', async (req, res) => {
    try
    {
        const tezostoday= await utuTemplateC.find({Currency:"tezos"}).select("Volume -_id").sort({date: -1}).limit(1)
        const tezos30d= await utuTemplateC.find({Currency:"tezos"}).select("Volume -_id").sort({date: -1}).skip(30).limit(1)
        console.log(tezostoday,tezos30d)
        var volStrToday = tezostoday.toString()
        var volStrYtd = tezos30d.toString()
        console.log(volStrToday,volStrYtd)
        var volTempToday = volStrToday.split(',').join('');
        var volTempYtd = volStrYtd.split(',').join('');
        console.log(volTempToday, volTempYtd)
        var finalVolToday= parseFloat(volTempToday.match(/[\d\.]+/))
        var finalVolYtd= parseFloat(volTempYtd.match(/[\d\.]+/))
        console.log(finalVolToday,finalVolYtd)
        
        
        var finalDiff = finalVolToday - finalVolYtd
        var finalDiffinPar = finalDiff/finalVolYtd*100
        console.log(finalDiff, finalDiffinPar)
        var outputDiff = finalDiffinPar.toFixed(2).toString()
        res.json(outputDiff+"%");
    }catch(err)
    {
        res.status(500).json({"cannot find tezos":err})
    }
});

router.get('/findbnb30dVdiff', async (req, res) => {
    try
    {
        const bnbtoday= await utuTemplateC.find({Currency:"bnb"}).select("Volume -_id").sort({date: -1}).limit(1)
        const bnb30d= await utuTemplateC.find({Currency:"bnb"}).select("Volume -_id").sort({date: -1}).skip(30).limit(1)
        console.log(bnbtoday,bnb30d)
        var volStrToday = bnbtoday.toString()
        var volStrYtd = bnb30d.toString()
        console.log(volStrToday,volStrYtd)
        var volTempToday = volStrToday.split(',').join('');
        var volTempYtd = volStrYtd.split(',').join('');
        console.log(volTempToday, volTempYtd)
        var finalVolToday= parseFloat(volTempToday.match(/[\d\.]+/))
        var finalVolYtd= parseFloat(volTempYtd.match(/[\d\.]+/))
        console.log(finalVolToday,finalVolYtd)
        
        
        var finalDiff = finalVolToday - finalVolYtd
        var finalDiffinPar = finalDiff/finalVolYtd*100
        console.log(finalDiff, finalDiffinPar)
        var outputDiff = finalDiffinPar.toFixed(2).toString()
        res.json(outputDiff+"%");
    }catch(err)
    {
        res.status(500).json({"cannot find bnb":err})
    }
});

router.get('/findbitcoin30dVdiff', async (req, res) => {
    try
    {
        const bitcointoday= await utuTemplateC.find({Currency:"bitcoin"}).select("Volume -_id").sort({date: -1}).limit(1)
        const bitcoin30d= await utuTemplateC.find({Currency:"bitcoin"}).select("Volume -_id").sort({date: -1}).skip(30).limit(1)
        console.log(bitcointoday,bitcoin30d)
        var volStrToday = bitcointoday.toString()
        var volStrYtd = bitcoin30d.toString()
        console.log(volStrToday,volStrYtd)
        var volTempToday = volStrToday.split(',').join('');
        var volTempYtd = volStrYtd.split(',').join('');
        console.log(volTempToday, volTempYtd)
        var finalVolToday= parseFloat(volTempToday.match(/[\d\.]+/))
        var finalVolYtd= parseFloat(volTempYtd.match(/[\d\.]+/))
        console.log(finalVolToday,finalVolYtd)
        
        
        var finalDiff = finalVolToday - finalVolYtd
        var finalDiffinPar = finalDiff/finalVolYtd*100
        console.log(finalDiff, finalDiffinPar)
        var outputDiff = finalDiffinPar.toFixed(2).toString()
        res.json(outputDiff+"%");
    }catch(err)
    {
        res.status(500).json({"cannot find bitcoin":err})
    }
});

router.get('/findbitcash30dVdiff', async (req, res) => {
    try
    {
        const bitcashtoday= await utuTemplateC.find({Currency:"bitcoin-cash"}).select("Volume -_id").sort({date: -1}).limit(1)
        const bitcash30d= await utuTemplateC.find({Currency:"bitcoin-cash"}).select("Volume -_id").sort({date: -1}).skip(30).limit(1)
        console.log(bitcashtoday,bitcash30d)
        var volStrToday = bitcashtoday.toString()
        var volStrYtd = bitcash30d.toString()
        console.log(volStrToday,volStrYtd)
        var volTempToday = volStrToday.split(',').join('');
        var volTempYtd = volStrYtd.split(',').join('');
        console.log(volTempToday, volTempYtd)
        var finalVolToday= parseFloat(volTempToday.match(/[\d\.]+/))
        var finalVolYtd= parseFloat(volTempYtd.match(/[\d\.]+/))
        console.log(finalVolToday,finalVolYtd)
        
        
        var finalDiff = finalVolToday - finalVolYtd
        var finalDiffinPar = finalDiff/finalVolYtd*100
        console.log(finalDiff, finalDiffinPar)
        var outputDiff = finalDiffinPar.toFixed(2).toString()
        res.json(outputDiff+"%");
    }catch(err)
    {
        res.status(500).json({"cannot find bitcash":err})
    }
});

router.get('/findbnb30dVdiff', async (req, res) => {
    try
    {
        const bnbtoday= await utuTemplateC.find({Currency:"bnb"}).select("Volume -_id").sort({date: -1}).limit(1)
        const bnb30d= await utuTemplateC.find({Currency:"bnb"}).select("Volume -_id").sort({date: -1}).skip(30).limit(1)
        console.log(bnbtoday,bnb30d)
        var volStrToday = bnbtoday.toString()
        var volStrYtd = bnb30d.toString()
        console.log(volStrToday,volStrYtd)
        var volTempToday = volStrToday.split(',').join('');
        var volTempYtd = volStrYtd.split(',').join('');
        console.log(volTempToday, volTempYtd)
        var finalVolToday= parseFloat(volTempToday.match(/[\d\.]+/))
        var finalVolYtd= parseFloat(volTempYtd.match(/[\d\.]+/))
        console.log(finalVolToday,finalVolYtd)
        
        
        var finalDiff = finalVolToday - finalVolYtd
        var finalDiffinPar = finalDiff/finalVolYtd*100
        console.log(finalDiff, finalDiffinPar)
        var outputDiff = finalDiffinPar.toFixed(2).toString()
        res.json(outputDiff+"%");
    }catch(err)
    {
        res.status(500).json({"cannot find bnb":err})
    }
});

router.get('/findcardano30dVdiff', async (req, res) => {
    try
    {
        const cardanotoday= await utuTemplateC.find({Currency:"cardano"}).select("Volume -_id").sort({date: -1}).limit(1)
        const cardano30d= await utuTemplateC.find({Currency:"cardano"}).select("Volume -_id").sort({date: -1}).skip(30).limit(1)
        console.log(cardanotoday,cardano30d)
        var volStrToday = cardanotoday.toString()
        var volStrYtd = cardano30d.toString()
        console.log(volStrToday,volStrYtd)
        var volTempToday = volStrToday.split(',').join('');
        var volTempYtd = volStrYtd.split(',').join('');
        console.log(volTempToday, volTempYtd)
        var finalVolToday= parseFloat(volTempToday.match(/[\d\.]+/))
        var finalVolYtd= parseFloat(volTempYtd.match(/[\d\.]+/))
        console.log(finalVolToday,finalVolYtd)
        
        
        var finalDiff = finalVolToday - finalVolYtd
        var finalDiffinPar = finalDiff/finalVolYtd*100
        console.log(finalDiff, finalDiffinPar)
        var outputDiff = finalDiffinPar.toFixed(2).toString()
        res.json(outputDiff+"%");
    }catch(err)
    {
        res.status(500).json({"cannot find cardano":err})
    }
});
module.exports = router