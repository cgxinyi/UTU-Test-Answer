const mongoose = require('mongoose')

const utuTemplate = new mongoose.Schema({
    _id: mongoose.Types.ObjectId,
    Currency: String,
    Date: Date,
    Open: String,
    High: String,
    Low: String,
    Close: String,
    Volume: String,
    MktCap: String, 
}, { collection : 'utuDataSet' })

var utudata = module.exports = mongoose.model('UTUDB', utuTemplate)
module.exports.get = function (callback, limit) {
    utudata.find(callback).limit(limit); 
 }
